(function(global){

    System.config({
        transpiler:'typescript',
        map:{
            app:'app'
        },
        packages:{
            app:{
                main:'./Calc.js',
                defaultExtension:'js'
            }
        }
    })


})(this)