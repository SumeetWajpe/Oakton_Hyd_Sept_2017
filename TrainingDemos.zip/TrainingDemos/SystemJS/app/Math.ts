export function Add(x:number,y:number):number{
        return x + y;
}

export function Product(x:number,y:number):number{
    return x * y;
}

function Subtract(x:number,y:number):number{
    return x - y;
}

export default Subtract;
