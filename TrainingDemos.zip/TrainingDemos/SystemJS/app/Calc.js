"use strict";
exports.__esModule = true;
var Math_1 = require("./Math");
console.log('The Addition is : ' + Math_1.Add(20, 30));
console.log('The Difference is : ' + Math_1["default"](20, 30));
