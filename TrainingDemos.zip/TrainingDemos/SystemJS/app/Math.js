"use strict";
exports.__esModule = true;
function Add(x, y) {
    return x + y;
}
exports.Add = Add;
function Product(x, y) {
    return x * y;
}
exports.Product = Product;
function Subtract(x, y) {
    return x - y;
}
exports["default"] = Subtract;
