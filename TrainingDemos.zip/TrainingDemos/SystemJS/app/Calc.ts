import Subtraction, {Add} from './Math';

console.log('The Addition is : ' + Add(20, 30))
console.log('The Difference is : ' + Subtraction(20, 30))