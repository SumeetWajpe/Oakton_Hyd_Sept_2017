module.exports = {
    entry:"./app/main.ts",
    output:{
        filename:"bundle.js",
        path:__dirname+ "/dist"
    },
    // Used for generating source maps used in debugging !
    devtool:'source-map',
    resolve:{
        extensions:[".ts",".js"]
    },
   // externals:[/^@angular\//],
    module:{
        loaders:[
            {
            test:/\.ts?$/,loader : 'awesome-typescript-loader'
            }
        ]
    }
}