import {Component,Input} from '@angular/core';

@Component({
    selector:'shoppingcart',
    //template:` `,
    templateUrl:'./app/shoppingcart.html',
    styles:[`
    
    input.ng-pristine.ng-invalid{
        background-color:pink;
    }
    input.ng-dirty.ng-valid{
        background-color:lightgreen;
    }
    input.ng-dirty.ng-invalid{
        border:2px solid red;
    }
    
    `]
})
export class ShoppingCartComponent{


//   product1:any =  {name: 'Lappy', price: 50000, quantity: 100, rating: 4, launchdate: new Date()   };
//   product2:any = { name: 'LED TV', price: 25000, quantity: 10, rating: 3.4587, launchdate: new Date()};
//     product3:any = { name: 'Desktop', price: 10000, quantity: 200, rating: 3, launchdate: new Date() };
//     product4:any = { name: 'Mobile', price: 20000, quantity: 1000, rating: 5, launchdate: new Date() };
//  product5:any =  { name: 'Camera', price: 90000, quantity: 10, rating: 4, launchdate: new Date()   }

productToBeSearched:string="";

    newProduct:any = {description:'Some Data !'};

    products: any[] = [
        {
            name: 'Lappy', likes:10, price: 50000, quantity: 100, rating: 4, launchdate: new Date() ,available:true,description:`Nearly years ago, Dakshin Mashaldanga ceased to be a Bangladeshi chitmahal (enclave) and became part of mainland India. But the absence of electricity even now rankles among all, especially cricket-crazy teenagers like Bilal and Maidul who can't watch the IPL at home"`   },
        { name: 'LED TV',likes:100, price: 25000, quantity: 10, rating: 3.4587, launchdate: new Date(), available: true,description:`Nearly years ago, Dakshin Mashaldanga ceased to be a Bangladeshi chitmahal (enclave) and became part of mainland India. But the absence of electricity even now rankles among all, especially cricket-crazy teenagers like Bilal and Maidul who can't watch the IPL at home"`  },
        { name: 'Desktop',likes:400, price: 10000, quantity: 200, rating: 3, launchdate: new Date(), available: false ,description:`Nearly years ago, Dakshin Mashaldanga ceased to be a Bangladeshi chitmahal (enclave) and became part of mainland India. But the absence of electricity even now rankles among all, especially cricket-crazy teenagers like Bilal and Maidul who can't watch the IPL at home"`  },
        { name: 'Mobile', likes:200,price: 20000, quantity: 1000, rating: 5, launchdate: new Date(), available: true,description:`Nearly years ago, Dakshin Mashaldanga ceased to be a Bangladeshi chitmahal (enclave) and became part of mainland India. But the absence of electricity even now rankles among all, especially cricket-crazy teenagers like Bilal and Maidul who can't watch the IPL at home"`  },
        { name: 'Camera',likes:500, price: 90000, quantity: 10, rating: 4, launchdate: new Date(), available: true,description:`Nearly years ago, Dakshin Mashaldanga ceased to be a Bangladeshi chitmahal (enclave) and became part of mainland India. But the absence of electricity even now rankles among all, especially cricket-crazy teenagers like Bilal and Maidul who can't watch the IPL at home"`   }
     ];  
    
     OnFormSubmit(thepassedForm:any){

        // var p = new Product(..)
            let newProductToBeAdded = {
                name:this.newProduct.name,
                price:this.newProduct.price,
                rating:this.newProduct.rating,
                quantity:this.newProduct.quantity,
                description:this.newProduct.description
            }

            if(thepassedForm.valid){
                    this.products.push(newProductToBeAdded);            
            }

     }
}