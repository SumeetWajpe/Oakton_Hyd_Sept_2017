import {Component} from '@angular/core';

import {ProductService} from './product.service';

@Component({
    selector:'useproductservice',
    template:`
    
<div style="width:500px;border:2px solid red">
<h1> Product Service Component </h1>
    <input type="text" [(ngModel)]="productToBeAdded" />
<input type="button" (click)="ClickHandler()" value="Add Product>>" /> 
<input type="button" (click)="GetProductHandler()" value="Get Product !" />
{{productReceived}}
</div>    `//,    providers:[ProductService]
})
export class UseProductServiceComponent{
// DI of ProductService
    constructor(private serviceObj:ProductService){}
    productToBeAdded:string="";
    productReceived:string=""
    ClickHandler(){
           this.serviceObj.insertNewProduct(this.productToBeAdded);
    }
    GetProductHandler(){
      this.productReceived = this.serviceObj.getRandomProduct();
    }

}