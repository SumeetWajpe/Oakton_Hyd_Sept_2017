import {Http} from '@angular/http';
import {Injectable} from '@angular/core';

import 'rxjs/add/operator/toPromise';

@Injectable()
export class PostsService{
        constructor(private httpObj:Http){

        }

        // getPosts(callBackFunc:any){
        //     // make ajaxified request !
        //     this.httpObj.get('https://jsonplaceholder.typicode.com/posts').subscribe(function(response){
        //         callBackFunc(response.json()) ;
        //     })
        // }


        getPosts(){
            // make ajaxified request !
          return   this.httpObj.get('https://jsonplaceholder.typicode.com/posts').toPromise();
        }

}