import {Component,Input,Output,EventEmitter} from '@angular/core';

@Component({
    selector:'likes',
    template:`
    <button class="btn btn-success" 
    (click)="OnIncrement()"
    ><span class="glyphicon glyphicon-thumbs-up"></span></button>
    <button class="btn btn-danger" (click)="OnDecrement()"><span class="glyphicon glyphicon-thumbs-down" ></span></button>
    {{likes}}
    `
})
export class LikesComponent{
//   @Input('name')  coursename:string = "Angular";
 @Input('count')  likes:number=0;

 @Output() changeLikes: EventEmitter<number> = new EventEmitter<number>();
OnIncrement(){
    // emit the event !
    this.likes +=1;
    this.changeLikes.emit(this.likes);
}

OnDecrement(){
    this.likes -=1;
    
}
}