"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var AppComponent = (function () {
    function AppComponent() {
        this.name = 'Angular 2.0';
        this.url = "https://www.ag-grid.com/images/angular2.png";
        this.IsSuccess = true;
        this.course1 = { title: "ReactJS" };
        this.course2 = { title: "Node" };
        this.heading = 'Shopping Cart !';
    }
    AppComponent.prototype.OnChangeOfTextHandler = function (evt) {
        //console.log(evt);
        this.heading = evt.target.value;
    };
    AppComponent.prototype.OnClickHandler = function () {
        this.heading = "Welcome to Shopping Cart !";
    };
    return AppComponent;
}());
AppComponent = __decorate([
    core_1.Component({
        selector: 'my-app',
        // template: `<h1>Hello {{name}}</h1>
        // <img src="{{url}}" height="200px" width="200px" />
        // <img [src]="url" height="200px" width="200px" />
        // <input type="button" class="btn" 
        // [class.btn-success]="IsSuccess"value="Bootstraped !" />
        // <input type="button" [style.backgroundColor]="IsSuccess ? 'green' : 'red' " value="Prop Binding !" />
        // <course></course>
        // <course [details]="course1"></course>
        // <course [details]="course2"></course>  
        // `,
        // template:`
        // <h1>{{heading}}</h1>
        //   <input type="text" [value]="heading" (input)="OnChangeOfTextHandler($event )"/>
        //   <input type="text" [(ngModel)]="heading" />
        // <input type="button" class="btn btn-primary" value="Change Title !" (click)="OnClickHandler()" />
        // <br/>
        // If Success ? :
        // <input type="checkbox" [(ngModel)]="IsSuccess" />
        // <input type="button" class="btn" 
        //  [class.btn-success]="IsSuccess"value="Bootstraped !" />
        // <shoppingcart></shoppingcart>
        // `
        // template:`<useproductservice></useproductservice>
        // <useproductservice></useproductservice>
        // `
        //template: `<post></post>`
        template: "<h1> Using Routing </h1>\n\n  <nav>\n      <a routerLink=\"/posts\" class=\"btn btn-primary\">Posts </a>\n      <a routerLink=\"/cart\" class=\"btn btn-primary\">Cart </a>\n  </nav>\n\n  <user></user>\n\n      <router-outlet></router-outlet>\n\n  "
    })
], AppComponent);
exports.AppComponent = AppComponent;
//# sourceMappingURL=app.component.js.map