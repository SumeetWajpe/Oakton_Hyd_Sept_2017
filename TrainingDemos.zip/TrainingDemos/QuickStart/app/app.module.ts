import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {FormsModule} from '@angular/forms';
import {HttpModule} from '@angular/http';

import {RouterModule,Routes} from '@angular/router';

import { AppComponent }  from './app.component';
import {CourseComponent} from './course.component';
import {ShoppingCartComponent} from './shoppingcart.component';
import {LikesComponent} from './likes.component';


import {ProductComponent} from './product.component';

import {UseProductServiceComponent} from './useproductservice.component'

import {CutShort} from './cutshort';
import {PostsComponent}  from './post.component' 
import {ProductService} from './product.service';

import {PostDetailComponent} from './postdetail.component';


import {HoverDirective} from './hoverOnProducts.directive'

import {UserDirective} from './users.directive';

import {UserComponent} from './user.component'

const routes:Routes=[
  {path:'posts',component:PostsComponent},
  {path:'post/:id',component:PostDetailComponent},
  {path:'cart',component:ShoppingCartComponent} ,
  {path:'',redirectTo:'/cart',pathMatch:'full'} ,
  {path:'**',redirectTo:'/posts',pathMatch:'full'}   
];

@NgModule({
  imports:      [ BrowserModule,FormsModule,HttpModule,RouterModule.forRoot(routes) ],
  declarations: [ AppComponent,CourseComponent ,ShoppingCartComponent,
    CutShort,ProductComponent,LikesComponent,UseProductServiceComponent,PostsComponent,PostDetailComponent,HoverDirective,UserDirective,UserComponent],
  bootstrap:    [ AppComponent ],
  providers:[ProductService]
})
export class AppModule { }
