export class ProductService{
    products:string[]  = ['TV','Laptop','Mobile','Washing Machine'];


        getProducts():string[]{
                return this.products;
        }

        getRandomProduct():string{
            return this.products[Math.floor(Math.random() * this.products.length)]
        }

        insertNewProduct(newProduct:string){
            this.products.push(newProduct);
        }

}