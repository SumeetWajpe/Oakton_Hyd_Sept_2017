"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var ProductService = (function () {
    function ProductService() {
        this.products = ['TV', 'Laptop', 'Mobile', 'Washing Machine'];
    }
    ProductService.prototype.getProducts = function () {
        return this.products;
    };
    ProductService.prototype.getRandomProduct = function () {
        return this.products[Math.floor(Math.random() * this.products.length)];
    };
    ProductService.prototype.insertNewProduct = function (newProduct) {
        this.products.push(newProduct);
    };
    return ProductService;
}());
exports.ProductService = ProductService;
//# sourceMappingURL=product.service.js.map