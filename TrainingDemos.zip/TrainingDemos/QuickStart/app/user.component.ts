import {Component} from '@angular/core';

@Component({
    selector:'user',
    template:`
    <div  *ngFor="let user of users">
    <div  *userdirective="user">
           <b> {{user.name}} </b>
    </div>
    </div>

    `
})
export class UserComponent{

    users:any[] = [
        {name:'Sumeet',certification:'MCT'},
        {name:'Amitabh',certification:'MCPD'},
        {name:'Tejas',certification:'MCT'}        
    ];
}