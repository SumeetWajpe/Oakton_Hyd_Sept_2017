import {Directive,TemplateRef,Input,ViewContainerRef} from '@angular/core';

@Directive({
    selector:'[userdirective]'
})
export class UserDirective{
        constructor(private tempRef:TemplateRef<any>,private viewContainer:ViewContainerRef){
        }

        @Input() set userdirective(user:any){
            if(user.certification == 'MCT'){
                this.viewContainer.createEmbeddedView(this.tempRef)
            }
        }


}