import {Component,OnInit} from '@angular/core';
import {PostsService} from './posts.service';


@Component({
     selector:'post',    
    template:`<h1> Posts : </h1>
<ul >
    <li *ngFor="let p of postsData">
    <a [routerLink]="['/post',p.id]"> {{p.title}} </a></li>
</ul>

    `,
       providers:[PostsService]
})
export class PostsComponent implements OnInit{

    postsData:any;
    constructor(private postServObj:PostsService){
    //   this.postServObj.getPosts((dataFromService:any)=>{
    //         this.postsData = dataFromService; 
    //    });

    
      
    }

    ngOnInit(){
        var aPromise = this.postServObj.getPosts();
        
            aPromise.then((responseFromService)=>{
                this.postsData = responseFromService.json(); 
            }
            ,(err)=>{
                console.log(err)
            });
    }
}