import { Component } from '@angular/core';



@Component({
  selector: 'my-app',
  // template: `<h1>Hello {{name}}</h1>

  // <img src="{{url}}" height="200px" width="200px" />

  // <img [src]="url" height="200px" width="200px" />

  // <input type="button" class="btn" 
  // [class.btn-success]="IsSuccess"value="Bootstraped !" />

  // <input type="button" [style.backgroundColor]="IsSuccess ? 'green' : 'red' " value="Prop Binding !" />
  // <course></course>
  // <course [details]="course1"></course>
  // <course [details]="course2"></course>  
  // `,
  // template:`

  // <h1>{{heading}}</h1>

  //   <input type="text" [value]="heading" (input)="OnChangeOfTextHandler($event )"/>

  //   <input type="text" [(ngModel)]="heading" />

  // <input type="button" class="btn btn-primary" value="Change Title !" (click)="OnClickHandler()" />


  // <br/>

  // If Success ? :

  // <input type="checkbox" [(ngModel)]="IsSuccess" />

  // <input type="button" class="btn" 
  //  [class.btn-success]="IsSuccess"value="Bootstraped !" />
  // <shoppingcart></shoppingcart>
  // `
  // template:`<useproductservice></useproductservice>
  // <useproductservice></useproductservice>
  // `

  //template: `<post></post>`
  template:`<h1> Using Routing </h1>

  <nav>
      <a routerLink="/posts" class="btn btn-primary">Posts </a>
      <a routerLink="/cart" class="btn btn-primary">Cart </a>
  </nav>

  <user></user>

      <router-outlet></router-outlet>

  `
})
export class AppComponent  { name = 'Angular 2.0'; 
url:string="https://www.ag-grid.com/images/angular2.png";
IsSuccess:boolean = true;
course1:any = {title:"ReactJS"};
course2:any = {title: "Node"};
heading:string='Shopping Cart !'


OnChangeOfTextHandler(evt:any){
  //console.log(evt);
  this.heading = evt.target.value;
}

OnClickHandler(){
      this.heading = "Welcome to Shopping Cart !";
}

}
