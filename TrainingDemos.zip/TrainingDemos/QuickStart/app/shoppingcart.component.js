"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var ShoppingCartComponent = (function () {
    function ShoppingCartComponent() {
        //   product1:any =  {name: 'Lappy', price: 50000, quantity: 100, rating: 4, launchdate: new Date()   };
        //   product2:any = { name: 'LED TV', price: 25000, quantity: 10, rating: 3.4587, launchdate: new Date()};
        //     product3:any = { name: 'Desktop', price: 10000, quantity: 200, rating: 3, launchdate: new Date() };
        //     product4:any = { name: 'Mobile', price: 20000, quantity: 1000, rating: 5, launchdate: new Date() };
        //  product5:any =  { name: 'Camera', price: 90000, quantity: 10, rating: 4, launchdate: new Date()   }
        this.productToBeSearched = "";
        this.newProduct = { description: 'Some Data !' };
        this.products = [
            {
                name: 'Lappy', likes: 10, price: 50000, quantity: 100, rating: 4, launchdate: new Date(), available: true, description: "Nearly years ago, Dakshin Mashaldanga ceased to be a Bangladeshi chitmahal (enclave) and became part of mainland India. But the absence of electricity even now rankles among all, especially cricket-crazy teenagers like Bilal and Maidul who can't watch the IPL at home\""
            },
            { name: 'LED TV', likes: 100, price: 25000, quantity: 10, rating: 3.4587, launchdate: new Date(), available: true, description: "Nearly years ago, Dakshin Mashaldanga ceased to be a Bangladeshi chitmahal (enclave) and became part of mainland India. But the absence of electricity even now rankles among all, especially cricket-crazy teenagers like Bilal and Maidul who can't watch the IPL at home\"" },
            { name: 'Desktop', likes: 400, price: 10000, quantity: 200, rating: 3, launchdate: new Date(), available: false, description: "Nearly years ago, Dakshin Mashaldanga ceased to be a Bangladeshi chitmahal (enclave) and became part of mainland India. But the absence of electricity even now rankles among all, especially cricket-crazy teenagers like Bilal and Maidul who can't watch the IPL at home\"" },
            { name: 'Mobile', likes: 200, price: 20000, quantity: 1000, rating: 5, launchdate: new Date(), available: true, description: "Nearly years ago, Dakshin Mashaldanga ceased to be a Bangladeshi chitmahal (enclave) and became part of mainland India. But the absence of electricity even now rankles among all, especially cricket-crazy teenagers like Bilal and Maidul who can't watch the IPL at home\"" },
            { name: 'Camera', likes: 500, price: 90000, quantity: 10, rating: 4, launchdate: new Date(), available: true, description: "Nearly years ago, Dakshin Mashaldanga ceased to be a Bangladeshi chitmahal (enclave) and became part of mainland India. But the absence of electricity even now rankles among all, especially cricket-crazy teenagers like Bilal and Maidul who can't watch the IPL at home\"" }
        ];
    }
    ShoppingCartComponent.prototype.OnFormSubmit = function (thepassedForm) {
        // var p = new Product(..)
        var newProductToBeAdded = {
            name: this.newProduct.name,
            price: this.newProduct.price,
            rating: this.newProduct.rating,
            quantity: this.newProduct.quantity,
            description: this.newProduct.description
        };
        if (thepassedForm.valid) {
            this.products.push(newProductToBeAdded);
        }
    };
    return ShoppingCartComponent;
}());
ShoppingCartComponent = __decorate([
    core_1.Component({
        selector: 'shoppingcart',
        //template:` `,
        templateUrl: './app/shoppingcart.html',
        styles: ["\n    \n    input.ng-pristine.ng-invalid{\n        background-color:pink;\n    }\n    input.ng-dirty.ng-valid{\n        background-color:lightgreen;\n    }\n    input.ng-dirty.ng-invalid{\n        border:2px solid red;\n    }\n    \n    "]
    })
], ShoppingCartComponent);
exports.ShoppingCartComponent = ShoppingCartComponent;
//# sourceMappingURL=shoppingcart.component.js.map