import {Component,Input} from '@angular/core';

@Component({
    selector:'product',
    template:`
    <div    productStyle [productColor]="'lightgreen'">
    <likes [count]="prodDetails.likes" (changeLikes)="ChangeLikesHandler($event)"></likes>
    <h2> {{prodDetails.name | uppercase  }} </h2>
                    <b> Price :  </b> {{prodDetails.price | currency:'INR':true    }} <br/>
                    <b> Quantity :  </b> {{prodDetails.quantity }} <br/>
                    <b> Rating :  </b> {{prodDetails.rating | number:'1.1-2'   }} <br/> 
                    <b> Launch Date :  </b> {{prodDetails.launchdate | date:'medium'   }} <br/> 
                    <b> Likes :  </b> {{prodDetails.likes  }} <br/> 
                    <b> Description :  </b> {{prodDetails.description | cutshort:50  }} <br/> 
                    
                    
        </div> `,
        // styles:[`
        
        // .Product{
        //     background-color:lightblue;
        //     border:2px solid black;
        //     border-radius:10px;
        //     margin:20px;
        //     padding:20px;
        // }
        
        // `]
        styleUrls:['./app/ProductStyles.css']
})
export class ProductComponent{

    @Input('pdetails') prodDetails:any = {};

    ChangeLikesHandler(e:number){
            this.prodDetails.likes = e;
    }
}