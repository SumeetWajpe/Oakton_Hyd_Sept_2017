import {Component,Input} from '@angular/core';

@Component({
    selector:'course',
    template:'<h1> {{ coursedetails.title }} </h1>'
})
export class CourseComponent{
//   @Input('name')  coursename:string = "Angular";
@Input('details') coursedetails:any = {title:'Angular'};
}