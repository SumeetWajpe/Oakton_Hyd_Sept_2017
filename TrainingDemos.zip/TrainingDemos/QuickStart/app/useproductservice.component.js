"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var product_service_1 = require("./product.service");
var UseProductServiceComponent = (function () {
    // DI of ProductService
    function UseProductServiceComponent(serviceObj) {
        this.serviceObj = serviceObj;
        this.productToBeAdded = "";
        this.productReceived = "";
    }
    UseProductServiceComponent.prototype.ClickHandler = function () {
        this.serviceObj.insertNewProduct(this.productToBeAdded);
    };
    UseProductServiceComponent.prototype.GetProductHandler = function () {
        this.productReceived = this.serviceObj.getRandomProduct();
    };
    return UseProductServiceComponent;
}());
UseProductServiceComponent = __decorate([
    core_1.Component({
        selector: 'useproductservice',
        template: "\n    \n<div style=\"width:500px;border:2px solid red\">\n<h1> Product Service Component </h1>\n    <input type=\"text\" [(ngModel)]=\"productToBeAdded\" />\n<input type=\"button\" (click)=\"ClickHandler()\" value=\"Add Product>>\" /> \n<input type=\"button\" (click)=\"GetProductHandler()\" value=\"Get Product !\" />\n{{productReceived}}\n</div>    " //,    providers:[ProductService]
    }),
    __metadata("design:paramtypes", [product_service_1.ProductService])
], UseProductServiceComponent);
exports.UseProductServiceComponent = UseProductServiceComponent;
//# sourceMappingURL=useproductservice.component.js.map