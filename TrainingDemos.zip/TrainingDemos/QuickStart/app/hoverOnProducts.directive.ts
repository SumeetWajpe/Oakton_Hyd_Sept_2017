import {Directive,ElementRef,Input,HostListener} from '@angular/core';


@Directive({
    selector:'[productStyle]'
})
export class HoverDirective{
   @Input('productColor') color:string = "";

    constructor(private refEle:ElementRef){

    }

    ngOnInit(){
        this.refEle.nativeElement.style.backgroundColor = this.color;

        this.refEle.nativeElement.style.border = "2px solid red";

        this.refEle.nativeElement.style.margin ="20px";

        this.refEle.nativeElement.style.padding ="20px";
    }

  @HostListener('mouseenter')  OnMouseEnter(){
    this.refEle.nativeElement.style.backgroundColor = "orange";
    }

    @HostListener('mouseleave')  OnMouseLeave(){
        this.refEle.nativeElement.style.backgroundColor = this.color;
        }
}