"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var LikesComponent = (function () {
    function LikesComponent() {
        //   @Input('name')  coursename:string = "Angular";
        this.likes = 0;
        this.changeLikes = new core_1.EventEmitter();
    }
    LikesComponent.prototype.OnIncrement = function () {
        // emit the event !
        this.likes += 1;
        this.changeLikes.emit(this.likes);
    };
    LikesComponent.prototype.OnDecrement = function () {
        this.likes -= 1;
    };
    return LikesComponent;
}());
__decorate([
    core_1.Input('count'),
    __metadata("design:type", Number)
], LikesComponent.prototype, "likes", void 0);
__decorate([
    core_1.Output(),
    __metadata("design:type", core_1.EventEmitter)
], LikesComponent.prototype, "changeLikes", void 0);
LikesComponent = __decorate([
    core_1.Component({
        selector: 'likes',
        template: "\n    <button class=\"btn btn-success\" \n    (click)=\"OnIncrement()\"\n    ><span class=\"glyphicon glyphicon-thumbs-up\"></span></button>\n    <button class=\"btn btn-danger\" (click)=\"OnDecrement()\"><span class=\"glyphicon glyphicon-thumbs-down\" ></span></button>\n    {{likes}}\n    "
    })
], LikesComponent);
exports.LikesComponent = LikesComponent;
//# sourceMappingURL=likes.component.js.map