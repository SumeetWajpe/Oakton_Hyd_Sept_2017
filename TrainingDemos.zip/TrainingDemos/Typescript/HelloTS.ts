// var x = 100;
// x = "Hello !";

var x = 100; // type inference !
var y:number = 200; // type annotation

// if(true){
//     let month = "Sept";

//     if(true){
//         let month = "Oct"
//         console.log(month);
//     }
// }

const PI = 3.14;
//PI = 3.14657;

const person = {Name:'Sumeet',Location:'Hyderabad'};

let z;
z = 100;
z = "Hello !";

// function Add(x:number,y:number):number{
//     return x + y;
// }

// let result:number = Add(10,20);

// function Add(x,y){

// }

enum Designations{
    Developer,
    Trainer = 100,
    Tester,
    Architect
}

let desn:Designations;
desn = Designations.Tester;

//console.log(Designations[desn]); // string representation
//console.log(desn); // numeric value

// let player:any = {Name:'Virat Kohli',Age:26};

// let cars:string[] = ['BMW','Fiat','Mahindra'];

// let moreCars:Array<string> = new Array<string>('Tata','Honda','Hyundai');

// for(var c in cars){
//     console.log(cars[c]);
// }

// for(let car of cars){
//     console.log(car);
// }


enum Category{
    Inspirational,
    Autobiography,
    Fiction,
    Comedy
}

function GetAllBooks():any[]{
    let allBooks:any[] = [
        {Title:'Wings of Fire',Author:'Dr. APJ Abdul Kalam',Price:800,Rating:4,Category:Category.Autobiography},
        {Title:'I am Malala',Author:'Malala',Price:800,Rating:3,Category:Category.Autobiography},
         {Title:'India 2020',Author:'Dr. APJ Abdul Kalam',Price:900,Rating:5,Category:Category.Inspirational},
          {Title:'Mruntunjay',Author:'Ranjit Desai',Price:800,Rating:4,Category:Category.Fiction},
           {Title:'Mourning Silence',Author:'Roy Doy',Price:1000,Rating:2,Category:Category.Fiction}
    ];
    return allBooks;
}

var AllBooks:any[] = GetAllBooks();

// for(let book of AllBooks){
//     console.log(book.Title);
// }

function GetBooksByCategory(categoryFilter:Category):string[]{
    var selectedBooks:string[] = [];
    for(var book of AllBooks){
        if(book.Category == categoryFilter){
            selectedBooks.push(book.Title);
        }
    }
    return selectedBooks;
}
let autobiographyBooks:string[] = GetBooksByCategory(Category.Autobiography);
for(let book of autobiographyBooks){
    console.log(book)
}


// var Square = function(x:number):number{
//     return x * x;
// }

//var Square = (x:number):number => {return x * x}

var Square = x => x * x;

console.log(Square(20));

// cars.forEach(function(car){
//     console.log(car);
// }); 

// // Arrow functions

// cars.forEach(car =>console.log(car));

// Optional Parameters
// function Print(noOfPages?:number,author?:string,printType?:string){
// noOfPages = noOfPages || 0;
// author = author || "unknown";
// console.log(noOfPages,author);
// }
// Print();
//Print(100,'A K Purab');

// function Print(noOfPages:number=0,author:string,printType:string="B/W"):void{
//  console.log(noOfPages,author,printType);
// }

//Print(undefined," K E Kepler ",undefined);
//Print(1000,'K E Kepler','Colour');


// REST parameters

// function Print(noOfPages:number,...restArgs:string[]){
//     console.log(restArgs);
// }

// Print(1000,"Pune",'Hyderabad','Gurugram');
// Print(2000,"Pune");

// Function Types
var IdGenerator : (name:string,id:number) => string;

function EmpIDGenerator(name:string,id:number):string{
        return name + id;
}

IdGenerator = EmpIDGenerator;

IdGenerator("EMP",1); // --> EmpIdGen

function ProdIDGenerator(name:string,id:number):string{
    return name + id;
}

IdGenerator = ProdIDGenerator;
IdGenerator("Product",10);

// Function Overloading
function GetBooks(rating:number):string[];
function GetBooks(author:string):string[];
function GetBooks(bookProperty:any,anotherBookProp?:any):string[]{
    let books:string[] = [];
    if( typeof bookProperty == "number"){
            // called using rating
    }
    if(typeof bookProperty == "string"){
        //called using author
    }
return books;
}

//GetBooks()

///  Spread Operator



let cars:string[] = [undefined,'Fiat','Mahindra'];

let moreCars:Array<string> = new Array<string>('Tata','Honda','Hyundai');

let allCars:any[] = [...cars,"Ferarri",...moreCars];
console.log(allCars);

//  String Interpolation !

cars.forEach((car,index)=>{
    console.log(`The car ${car} is at index ${index}`);
});

var str = `Hello !
Line 1
Line 2
`
// Destructuring (Arrays)

let car1,car2,car3,car4;

[car1="Hyundai",car2,car3,car4="Tata"] = cars;

console.log(car1,car4);

// Destructuring with Objects

let company = {Name:'Oakton',address:'HYD'};

let Name,address;

({Name} = company);

console.log(Name);

// Interfaces

// interface IPerson{
//     name:string;
//     age:number;
//     location?:string;
//     walk?:() => string;
// }


// let aPerson:IPerson = {name:'Sumeet',
// age:32,
// walk:function() {return'Walk and talk !'}
//  };

 /// Classes

//  class Car{
//      name:string;
//      speed:number;

//      constructor();
//      constructor(name:string,speed:number);     
//      constructor(name?:any,speed?:any){
//          this.name = name;
//          this.speed = speed;
//      }
//      Accelerate():void{
//          console.log(this.name + " running at (kmph) :" + this.speed);
//      }
//  }

//  var carObj = new Car("i20",200);
// carObj.Accelerate();


// class Car{
//     colour:string;
//     constructor(public name:string,public speed:number){

//     }
// }

// var carObj = new Car("i20",400);
// console.log(carObj.);


// Inheritance

//  class Car{     
//    constructor(public name:string,public speed:number){       
//      }
//     //  Accelerate():string{
//     //      return (this.name + " running at (kmph) :" + this.speed);
//     //  }

//     static Accelerate(carObj):string{
//         return (carObj.name + " running at (kmph) :" + carObj.speed);
//     }
//  }


//  var car = new Car("i20",400);
//  console.log(Car.Accelerate(car));


//  class JamesBondCar extends Car{
//      canFly:boolean ;
//      useNitro:boolean;

//      constructor(name:string,speed:number,canFly:boolean,useNitro:boolean){
//             super(name,speed);
//             this.canFly = canFly;
//             this.useNitro = useNitro;
//      }

//     //  static Accelerate():string{
//     //     return super.Accelerate() + " can Fly ? " + this.canFly;
//     //  }
//  }

//  var jbc = new JamesBondCar("Houston",400,true,false);

 //console.log(jbc.Accelerate());

 /// Classes And Intefaces


 class Human{

 }
 interface IPerson{
    name:string;
    age:number;
    location?:string;
    walk?:() => string;
}

interface IEmployee extends IPerson{
    salary:number;
}
class Person extends Human implements IEmployee {
    name:string;
    age:number;
    location:string;
    salary:number;
    walk():string{
        return '';
    }
    
}