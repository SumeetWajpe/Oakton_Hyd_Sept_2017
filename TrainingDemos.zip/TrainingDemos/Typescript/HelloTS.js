// var x = 100;
// x = "Hello !";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var x = 100; // type inference !
var y = 200; // type annotation
// if(true){
//     let month = "Sept";
//     if(true){
//         let month = "Oct"
//         console.log(month);
//     }
// }
var PI = 3.14;
//PI = 3.14657;
var person = { Name: 'Sumeet', Location: 'Hyderabad' };
var z;
z = 100;
z = "Hello !";
// function Add(x:number,y:number):number{
//     return x + y;
// }
// let result:number = Add(10,20);
// function Add(x,y){
// }
var Designations;
(function (Designations) {
    Designations[Designations["Developer"] = 0] = "Developer";
    Designations[Designations["Trainer"] = 100] = "Trainer";
    Designations[Designations["Tester"] = 101] = "Tester";
    Designations[Designations["Architect"] = 102] = "Architect";
})(Designations || (Designations = {}));
var desn;
desn = Designations.Tester;
//console.log(Designations[desn]); // string representation
//console.log(desn); // numeric value
// let player:any = {Name:'Virat Kohli',Age:26};
// let cars:string[] = ['BMW','Fiat','Mahindra'];
// let moreCars:Array<string> = new Array<string>('Tata','Honda','Hyundai');
// for(var c in cars){
//     console.log(cars[c]);
// }
// for(let car of cars){
//     console.log(car);
// }
var Category;
(function (Category) {
    Category[Category["Inspirational"] = 0] = "Inspirational";
    Category[Category["Autobiography"] = 1] = "Autobiography";
    Category[Category["Fiction"] = 2] = "Fiction";
    Category[Category["Comedy"] = 3] = "Comedy";
})(Category || (Category = {}));
function GetAllBooks() {
    var allBooks = [
        { Title: 'Wings of Fire', Author: 'Dr. APJ Abdul Kalam', Price: 800, Rating: 4, Category: Category.Autobiography },
        { Title: 'I am Malala', Author: 'Malala', Price: 800, Rating: 3, Category: Category.Autobiography },
        { Title: 'India 2020', Author: 'Dr. APJ Abdul Kalam', Price: 900, Rating: 5, Category: Category.Inspirational },
        { Title: 'Mruntunjay', Author: 'Ranjit Desai', Price: 800, Rating: 4, Category: Category.Fiction },
        { Title: 'Mourning Silence', Author: 'Roy Doy', Price: 1000, Rating: 2, Category: Category.Fiction }
    ];
    return allBooks;
}
var AllBooks = GetAllBooks();
// for(let book of AllBooks){
//     console.log(book.Title);
// }
function GetBooksByCategory(categoryFilter) {
    var selectedBooks = [];
    for (var _i = 0, AllBooks_1 = AllBooks; _i < AllBooks_1.length; _i++) {
        var book = AllBooks_1[_i];
        if (book.Category == categoryFilter) {
            selectedBooks.push(book.Title);
        }
    }
    return selectedBooks;
}
var autobiographyBooks = GetBooksByCategory(Category.Autobiography);
for (var _i = 0, autobiographyBooks_1 = autobiographyBooks; _i < autobiographyBooks_1.length; _i++) {
    var book = autobiographyBooks_1[_i];
    console.log(book);
}
// var Square = function(x:number):number{
//     return x * x;
// }
//var Square = (x:number):number => {return x * x}
var Square = function (x) { return x * x; };
console.log(Square(20));
// cars.forEach(function(car){
//     console.log(car);
// }); 
// // Arrow functions
// cars.forEach(car =>console.log(car));
// Optional Parameters
// function Print(noOfPages?:number,author?:string,printType?:string){
// noOfPages = noOfPages || 0;
// author = author || "unknown";
// console.log(noOfPages,author);
// }
// Print();
//Print(100,'A K Purab');
// function Print(noOfPages:number=0,author:string,printType:string="B/W"):void{
//  console.log(noOfPages,author,printType);
// }
//Print(undefined," K E Kepler ",undefined);
//Print(1000,'K E Kepler','Colour');
// REST parameters
// function Print(noOfPages:number,...restArgs:string[]){
//     console.log(restArgs);
// }
// Print(1000,"Pune",'Hyderabad','Gurugram');
// Print(2000,"Pune");
// Function Types
var IdGenerator;
function EmpIDGenerator(name, id) {
    return name + id;
}
IdGenerator = EmpIDGenerator;
IdGenerator("EMP", 1); // --> EmpIdGen
function ProdIDGenerator(name, id) {
    return name + id;
}
IdGenerator = ProdIDGenerator;
IdGenerator("Product", 10);
function GetBooks(bookProperty, anotherBookProp) {
    var books = [];
    if (typeof bookProperty == "number") {
        // called using rating
    }
    if (typeof bookProperty == "string") {
        //called using author
    }
    return books;
}
//GetBooks()
///  Spread Operator
var cars = [undefined, 'Fiat', 'Mahindra'];
var moreCars = new Array('Tata', 'Honda', 'Hyundai');
var allCars = cars.concat(["Ferarri"], moreCars);
console.log(allCars);
//  String Interpolation !
cars.forEach(function (car, index) {
    console.log("The car " + car + " is at index " + index);
});
var str = "Hello !\nLine 1\nLine 2\n";
// Destructuring (Arrays)
var car1, car2, car3, car4;
_a = cars[0], car1 = _a === void 0 ? "Hyundai" : _a, car2 = cars[1], car3 = cars[2], _b = cars[3], car4 = _b === void 0 ? "Tata" : _b;
console.log(car1, car4);
// Destructuring with Objects
var company = { Name: 'Oakton', address: 'HYD' };
var Name, address;
(Name = company.Name);
console.log(Name);
// Interfaces
// interface IPerson{
//     name:string;
//     age:number;
//     location?:string;
//     walk?:() => string;
// }
// let aPerson:IPerson = {name:'Sumeet',
// age:32,
// walk:function() {return'Walk and talk !'}
//  };
/// Classes
//  class Car{
//      name:string;
//      speed:number;
//      constructor();
//      constructor(name:string,speed:number);     
//      constructor(name?:any,speed?:any){
//          this.name = name;
//          this.speed = speed;
//      }
//      Accelerate():void{
//          console.log(this.name + " running at (kmph) :" + this.speed);
//      }
//  }
//  var carObj = new Car("i20",200);
// carObj.Accelerate();
// class Car{
//     colour:string;
//     constructor(public name:string,public speed:number){
//     }
// }
// var carObj = new Car("i20",400);
// console.log(carObj.);
// Inheritance
//  class Car{     
//    constructor(public name:string,public speed:number){       
//      }
//     //  Accelerate():string{
//     //      return (this.name + " running at (kmph) :" + this.speed);
//     //  }
//     static Accelerate(carObj):string{
//         return (carObj.name + " running at (kmph) :" + carObj.speed);
//     }
//  }
//  var car = new Car("i20",400);
//  console.log(Car.Accelerate(car));
//  class JamesBondCar extends Car{
//      canFly:boolean ;
//      useNitro:boolean;
//      constructor(name:string,speed:number,canFly:boolean,useNitro:boolean){
//             super(name,speed);
//             this.canFly = canFly;
//             this.useNitro = useNitro;
//      }
//     //  static Accelerate():string{
//     //     return super.Accelerate() + " can Fly ? " + this.canFly;
//     //  }
//  }
//  var jbc = new JamesBondCar("Houston",400,true,false);
//console.log(jbc.Accelerate());
/// Classes And Intefaces
var Human = (function () {
    function Human() {
    }
    return Human;
}());
var Person = (function (_super) {
    __extends(Person, _super);
    function Person() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    Person.prototype.walk = function () {
        return '';
    };
    return Person;
}(Human));
var _a, _b;
