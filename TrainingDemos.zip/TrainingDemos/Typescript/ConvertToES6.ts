let x:number = 1000;

function Add(x,y){
    return x + y;
}