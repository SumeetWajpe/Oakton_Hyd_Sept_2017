function Add(x,y){
    return x + y;
}

describe("A suite", function() {
    it("contains spec with an expectation", function() {
      expect(false).toBe(true);
    });
  });

  describe("A custom suite", function() {
    it("contains spec with an expectation to add two numbers", function() {
      expect(Add(20,50)).toBe(50);
    });
  });