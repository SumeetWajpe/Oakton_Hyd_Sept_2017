﻿console.log('Hello world');
let x = 100;