console.log('Hello world');
var x = 100;
//# sourceMappingURL=app.js.map